from pathlib import Path
import os,sys,json,time,statistics,sqlite3,subprocess,hashlib
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'project'))
os.environ['CYBER_DB_PATH']=str(r/'evidence/week8_runtime.db');assert os.environ.get('CYBER_USERNAME') and len(os.environ.get('CYBER_PASSWORD','')) >= 16, 'Configure credentials first'
from fastapi.testclient import TestClient
from src.api.app import app
c=TestClient(app);c.auth=(os.environ['CYBER_USERNAME'],os.environ['CYBER_PASSWORD'])
p=dict(event_id='U8-DEMO',timestamp='2026-10-26T12:00:00Z',source='vpn-gateway',event_type='login_failure',failed_attempts=8,known_bad_ip=1,privileged_account=1,severity=.9,business_impact=.8)
res=c.post('/analyze',json=p);assert res.status_code==200
out={'date':'2026-10-26','demo':res.json(),'closures':[]}
for key,value in [('event_id','  '),('timestamp','invalid'),('failed_attempts',-1),('known_bad_ip',2),('event_type','unsupported')]:
 q=p|{key:value};resp=c.post('/analyze',json=q);out['closures'].append({'field':key,'expected':422,'observed':resp.status_code});assert resp.status_code==422
resp=c.get('/events',auth=None);out['closures'].append({'field':'anonymous_history','expected':401,'observed':resp.status_code});assert resp.status_code==401
with sqlite3.connect(os.environ['CYBER_DB_PATH']) as db:before=db.execute('select count(*) from analyzed_events').fetchone()[0]
lat=[]
for i in range(100):
 q=p|{'event_id':f'U8-STABILITY-{i}'};t=time.perf_counter();res=c.post('/analyze',json=q);lat.append((time.perf_counter()-t)*1000);assert res.status_code==200
with sqlite3.connect(os.environ['CYBER_DB_PATH']) as db:after=db.execute('select count(*) from analyzed_events').fetchone()[0]
assert after-before==100
out['stability']={'requests':100,'new_rows':after-before,'mean_ms':statistics.mean(lat),'median_ms':statistics.median(lat),'p95_ms':sorted(lat)[94],'max_ms':max(lat),'latencies_ms':lat}
code='from src.database.database import list_analyses; import json; print(json.dumps(list_analyses(1)))'
rr=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,env=os.environ|{'PYTHONPATH':str(r/'project')},check=True);out['fresh_process']=json.loads(rr.stdout);assert out['fresh_process'][0]['event_id']=='U8-STABILITY-99'
files={str(f.relative_to(r/'project')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (r/'project').rglob('*') if f.is_file() and not any(s in str(f) for s in ['__pycache__','.pytest_cache','.db'])};out['source_sha256']=files
(r/'evidence/current_results.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['source_sha256','stability']},indent=2));print({k:v for k,v in out['stability'].items() if k!='latencies_ms'})
