# Unit 8 capstone source and evidence

This is the final local revision derived from public baseline commit 9d4cf2722093ab657e681976314e073647cc5b56. It has not been pushed or merged remotely. The API still uses the six-example event classifier. The native NSL-KDD candidate is an offline experiment only.

## Setup
Use Python 3.12 and an isolated virtual environment. Install the tested dependencies with `python -m pip install -r requirements-tested.txt`. The original broad project requirements are retained separately for provenance.

From the project directory, configure CYBER_USERNAME and CYBER_PASSWORD in your shell. The password must contain at least 16 characters. Use your own temporary local credentials; do not record them or commit them. CYBER_DB_PATH selects a fresh synthetic SQLite database. The application reads these variables from the environment and does not load .env automatically.

Start with `uvicorn src.api.app:app --host 127.0.0.1 --port 8000`. Open http://127.0.0.1:8000/ and enter credentials in the browser authentication prompt. Use a clean URL without credentials. Public health: /health. Protected routes: /, /analyze, /events. HTTP Basic is appropriate only for the loopback demonstration; use HTTPS and managed identity before external use. No container build or deployment has been verified.

## Verification
From project: `python -m pytest tests -v`. The recorded final suite has 33 passes and one deprecation warning. Tests use demonstration-only credentials and synthetic data. The fixtures isolate the new negative checks. The original integration test uses a fixed test database path; do not use it with real data.

From the archive root: `python run_current.py` repeats the six closure checks, a valid request, 100 authenticated requests, row-count verification, and fresh-process retrieval. Set the credentials first. It writes a new evidence database and JSON results; local timings will vary. Do not run it over original evidence when preserving the recorded run is required; first copy the archive to a separate working folder.

`python evaluate_external.py` repeats the independent legacy-benchmark experiment. It loads data/KDDTrain20.txt and data/KDDTest.txt and writes evidence/external_results.json. The frozen adapter is lossy; it never reads labels. The native candidate uses original predictor features, excludes label/difficulty metadata, removes 118 overlapping test feature vectors, and is not integrated into the API. This benchmark does not establish performance on contemporary SME telemetry.

## Data attribution
NSL-KDD originates from the Canadian Institute for Cybersecurity, University of New Brunswick: https://www.unb.ca/cic/datasets/nsl.html . That page permits mirroring with dataset and paper attribution. Downloaded from the public mirror https://github.com/Jehuty4949/NSL_KDD (original URL redirected from defcom17/NSL_KDD). Dataset hashes, byte sizes, sample counts, and experimental caveats are in evidence/external_results.json.

Tavallaee, M., Bagheri, E., Lu, W., & Ghorbani, A. A. (2009). A detailed analysis of the KDD CUP 99 data set. 2009 IEEE Symposium on Computational Intelligence for Security and Defense Applications. https://doi.org/10.1109/CISDA.2009.5356528

The supporting evidence includes dated log extracts and actual browser captures. Databases, caches, installed dependencies, and operational credentials are excluded. MANIFEST.json covers the delivered file contents. Historical Week 7 evidence is labeled separately from final results in the report.
