"""External legacy-benchmark stress test and separate native-feature experiment.
The frozen adapter never reads labels. Neither experiment establishes SME production accuracy.
"""
from pathlib import Path
import csv,json,hashlib,os,sys,time
import numpy as np
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import MaxAbsScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,confusion_matrix,roc_auc_score
root=Path(__file__).resolve().parent
os.environ['CYBER_DB_PATH']=str(root/'evidence/external.db')
sys.path.insert(0,str(root/'project'))
from src.api.app import classifier

def load(name):
 rows=list(csv.reader((root/'data'/name).open()));assert all(len(r)==43 for r in rows)
 X=[{f'f{i:02}':v if i in (1,2,3) else float(v) for i,v in enumerate(r[:41])} for r in rows]
 return rows,X,np.array([r[41]!='normal' for r in rows],dtype=int)
train,xt,yt=load('KDDTrain20.txt');test,xe,ye=load('KDDTest.txt')
# Freeze preprocessing without reading attack labels or difficulty metadata.
def adapt(r):
 failed=int(r[10]);logged=int(r[11]);root_shell=int(r[13])
 return dict(event_type='login_failure' if failed else ('login_success' if logged else 'file_read'),failed_attempts=failed,known_bad_ip=0,privileged_account=int(root_shell>0))
projected=[adapt(r) for r in test]
probs=classifier.pipeline.predict_proba(projected);classes=list(classifier.pipeline.named_steps['classifier'].classes_);score=probs[:,classes.index('suspicious')];pred=(score>=.5).astype(int)
def metrics(y,p,s):
 return dict(n=len(y),accuracy=float(accuracy_score(y,p)),precision=float(precision_score(y,p,zero_division=0)),recall=float(recall_score(y,p,zero_division=0)),f1=float(f1_score(y,p,zero_division=0)),roc_auc=float(roc_auc_score(y,s)),confusion_matrix=confusion_matrix(y,p).tolist(),normal=int((y==0).sum()),attack=int((y==1).sum()))
result={'dataset':'NSL-KDD KDDTrain+ 20 percent and KDDTest+', 'date':'2026-10-26','download_source':'https://github.com/Jehuty4949/NSL_KDD','files':{n:dict(sha256=hashlib.sha256((root/'data'/n).read_bytes()).hexdigest(),bytes=(root/'data'/n).stat().st_size) for n in ['KDDTrain20.txt','KDDTest.txt']},'frozen_event_model_projection':metrics(ye,pred,score)}
trainkeys={tuple(r[:41]) for r in train};keep=np.array([tuple(r[:41]) not in trainkeys for r in test]);result['native_train_rows']=len(train);result['test_rows_excluded_native_feature_overlap']=int((~keep).sum())
model=make_pipeline(DictVectorizer(),MaxAbsScaler(),LogisticRegression(solver='liblinear',max_iter=1000,random_state=42))
start=time.perf_counter();model.fit(xt,yt);result['native_fit_seconds']=time.perf_counter()-start
newx=[x for x,k in zip(xe,keep) if k];y=ye[keep];s=model.predict_proba(newx)[:,1];p=model.predict(newx)
result['offline_native_feature_candidate']=metrics(y,p,s)
result['candidate_not_integrated']=True
result['cautions']=['Legacy simulated network benchmark; not contemporary SME telemetry.','Frozen adapter maps failed logins directly, root_shell to privilege proxy, and assumes unknown reputation is zero.','Projected event categories are lossy proxies; frozen scores measure adapter-plus-model stress only.','Native candidate uses 41 original features, no label or difficulty field, trained only on the 20 percent training partition.','Native test feature vectors overlapping training are excluded; no parameter selection on test labels.','Candidate is an offline model, not deployed in the API.']
(root/'evidence/external_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
